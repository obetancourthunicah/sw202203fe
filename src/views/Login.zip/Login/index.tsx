import { useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useSignInMutation } from "@store/Services/Security";
import { setSecData } from "@store/Slices/secSlice";
import Page from "@components/Page";
import { PrimaryButton } from "@components/Buttons";
const Login = () => {
  const [signIn, { isLoading, status, error }] = useSignInMutation();
  const dispatch = useDispatch();
  const Navigator = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleClick = async () => {
    const data = await signIn({ email, password }).unwrap();
    dispatch(setSecData(data));
    Navigator("/home");
  };

  return (
    <Page>
      <h1>Login</h1>
      <form >
        <input
          type="text"
          placeholder="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="password"
          onChange={(e) => setPassword(e.target.value)}
        />
      </form>
      {error && <p>{JSON.stringify(error)}</p>}
      <PrimaryButton onClick={handleClick}>Login</PrimaryButton>
    </Page>
  );
};

export default Login;
